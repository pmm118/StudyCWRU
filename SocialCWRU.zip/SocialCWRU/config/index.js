require('dotenv').config(); // Load .env file contents into process.env

module.exports = {
    port: process.env.PORT || 3000,
    dbUrl: process.env.DB_URL,
};

//importing rooms routes
const express = require('express');
const app = express();
const roomsRoutes = require('./routes/rooms');

app.use(express.json()); // Middleware for parsing JSON
app.use('/rooms', roomsRoutes); // Prefix for room-related APIs

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));


