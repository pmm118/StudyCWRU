const express = require("express");
const bodyParser = require("body-parser");
const app = express();

const rooms = {}; // Store game rooms

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Create Room API
app.post("/rooms/create", (req, res) => {
    const roomId = Math.random().toString(36).substr(2, 6); // Generate unique ID
    rooms[roomId] = { players: [], board: Array(9).fill(null), turn: "X" };
    res.json({ roomId });
});

// Join Room API
app.post("/rooms/:id/join", (req, res) => {
    const { id } = req.params;
    const room = rooms[id];

    if (!room) return res.status(404).json({ error: "Room not found" });
    if (room.players.length >= 2) return res.status(400).json({ error: "Room is full" });

    room.players.push(req.body.username);
    res.json({ message: "Joined room", room });
});

// Start the server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});

