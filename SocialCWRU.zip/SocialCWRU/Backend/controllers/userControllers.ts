import { Request, Response } from "express";

export const getUsers = async (req: Request, res: Response) => {
    res.status(200).json({ message: "Fetching all users" });
};

export const createUser = async (req: Request, res: Response) => {
    const { name, email } = req.body;
    res.status(201).json({ message: "User created", data: { name, email } });
};
