//implenting controller logic
const rooms = {}; // Store rooms in memory for now

const createRoom = (req, res) => {
    try {
        const roomId = generateRoomId(); // Function to generate a unique room ID
        rooms[roomId] = {
            players: [],
            board: Array(9).fill(null), // Example for a Tic-Tac-Toe game
            turn: "X" // First player is "X"
        };
        res.status(201).json({ roomId });
    } catch (error) {
        console.error("Error creating room:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

// Function to generate a more unique room ID
const generateRoomId = () => {
    return Date.now().toString() + Math.floor(Math.random() * 1000); // Adding random value to make it even more unique
};

const joinRoom = (req, res) => {
    const roomId = req.params.id;
    const playerName = req.body.name;

    // Check if room exists
    if (!rooms[roomId]) {
        return res.status(404).json({ message: 'Room not found' });
    }

    // Check if room is full (assuming max of 2 players per room)
    if (rooms[roomId].players.length >= 2) {
        return res.status(400).json({ message: 'Room is full' });
    }

    // Check if player is already in the room
    if (rooms[roomId].players.includes(playerName)) {
        return res.status(400).json({ message: 'Player already in the room' });
    }

    // Add player to the room
    rooms[roomId].players.push(playerName);

    // Return updated room information
    res.status(200).json({ roomId, players: rooms[roomId].players });
};


module.exports = { createRoom, joinRoom };
