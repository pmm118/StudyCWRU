const express = require("express");
const router = express.Router();

// Define your routes
router.post("/create", (req, res) => {
    const roomId = Date.now().toString();
    rooms[roomId] = { players: [] };
    res.status(201).json({ roomId });
});

router.post("/:id/join", (req, res) => {
    const roomId = req.params.id;
    const playerName = req.body.name;

    if (!rooms[roomId]) {
        return res.status(404).json({ message: 'Room not found' });
    }

    rooms[roomId].players.push(playerName);
    res.status(200).json({ roomId, players: rooms[roomId].players });
});

module.exports = router;  // Make sure this line is here and is exporting the router correctly
