DATABASE_URL=mongodb+srv://adb208:QhfE6FPCMhpnGiO5@cluster0.zvcua.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0;
const apiKey = process.env.API_KEY;
API_KEY=apiKey-key
